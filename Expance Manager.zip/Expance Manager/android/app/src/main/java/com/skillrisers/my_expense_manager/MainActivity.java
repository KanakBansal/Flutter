package com.skillrisers.my_expense_manager;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
