import 'package:emi_calculator/File1.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(MyApp());
}