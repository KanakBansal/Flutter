import 'dart:math';

import 'package:flutter/material.dart';

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "EMI Calc.",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.grey),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final principalController = TextEditingController();
  final rateController = TextEditingController();
  final timeController = TextEditingController();
  // late final p;
  // late final r;
  // late final t;
  double? emi;
  double? interest;
  String result = "";
  String output = "";

  void emiValue() {
    final p = int.parse(principalController.text);
    final r = int.parse(rateController.text) / 1200;
    final t = int.parse(timeController.text);
    //interest = ((p) * (r) * (t) / 100);
    emi = (p*r* (pow(1+r, t) / (pow(1+r, t)-1)));
    result = emi.toString();
    setState(() => output = result);
  }

  @override
  void initState() {
    principalController.addListener(() => setState(() {}));
    rateController.addListener(() => setState(() {}));
    timeController.addListener(() => setState(() {}));
    super.initState();
  }

  @override
  void dispose() {
    principalController.dispose();
    rateController.dispose();
    timeController.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.menu),
        title: Text("EMI Calculator"),
      ),

      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Center(
          child: Column(
            children: [
              _principalAmount(),
              SizedBox(height: 10),
              _rate(),
              SizedBox(height: 10),
              _time(),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: emiValue,
                child: Text("Calculate"),
              ),
              Container(
                alignment: Alignment(0,1),
                child: Text(
                  "Your EMI is  : $output",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 30,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _principalAmount() {
    return TextField(
      controller: principalController,
      keyboardType: TextInputType.number,
      textInputAction: TextInputAction.next,
      //autofocus: true,
      decoration: InputDecoration(
        labelText: "Principal Amount",
        hintText: "Enter the Principal Amount",
        prefixIcon: Icon(Icons.attach_money),
        //suffixIcon: Icon(Icons.close),
        suffixIcon: principalController.text.isEmpty
            ? null
            : IconButton(
                onPressed: () {
                  principalController.clear();
                },
                icon: Icon(Icons.close),
              ),
        isDense: true,
        border: OutlineInputBorder(
          //borderSide: BorderSide(width: 20) ,
          borderRadius: BorderRadius.circular(20),
        ),
      ),
    );
  }

  Widget _rate() {
    return TextField(
      controller: rateController,
      keyboardType: TextInputType.number,
      textInputAction: TextInputAction.next,
      //autofocus: true,
      decoration: InputDecoration(
        labelText: "Rate of Interest",
        hintText: "Enter the Rate of Interest(per month)",
        prefixIcon: Icon(Icons.alternate_email_sharp),
        //suffixIcon: Icon(Icons.close),
        suffixIcon: rateController.text.isEmpty
            ? null
            : IconButton(
                onPressed: () {
                  rateController.clear();
                },
                icon: Icon(Icons.close),
              ),
        isDense: true,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
    );
  }

  Widget _time() {
    return TextField(
      controller: timeController,
      keyboardType: TextInputType.number,
      textInputAction: TextInputAction.next,
      //autofocus: true,
      decoration: InputDecoration(
        labelText: "Duration",
        hintText: "Enter the Duration(in months)",
        prefixIcon: Icon(Icons.timer),
        //suffixIcon: Icon(Icons.close),
        suffixIcon: timeController.text.isEmpty
            ? null
            : IconButton(
                onPressed: () {
                  timeController.clear();
                },
                icon: Icon(Icons.close),
              ),
        isDense: true,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(20),

        ),
      ),
    );
  }
}
