import 'package:flutter/material.dart';
import 'package:calculator/file1.dart';


void main(){
  runApp(MyApp());
}