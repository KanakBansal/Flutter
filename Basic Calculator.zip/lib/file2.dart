import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<String> operators = ["+", "-", "x", "÷"];
  int? firstNum;
  int? secondNum;
  String output = "0";
  String res = "";
  String history = "";
  String operation = "";

  bool isOperator(String value) {
    return (operators.contains(value));
  }

  btnOnClick(String btnValue) {
    print(btnValue);

    if (btnValue == "AC") {
      operation = "";
      output = "0";
      res = "0";
      history = "";
    }else if(btnValue == "%"){
      firstNum = int.parse(output);
      operation = btnValue;
      res = (firstNum! /100).toString();
      history=firstNum.toString() + operation.toString();
    } else if (isOperator(btnValue)) {
      firstNum = int.parse(output);
      operation = btnValue;
      res = "";
    } else if (btnValue == '=') {
      secondNum = int.parse(output);

      if (operation == "+") {
        res = (firstNum! + secondNum!).toString();
        history =
            firstNum.toString() + operation.toString() + secondNum.toString();
      }

      if (operation == "-") {
        res = (firstNum! - secondNum!).toString();
        history =
            firstNum.toString() + operation.toString() + secondNum.toString();
      }

      if (operation == "x") {
        res = (firstNum! * secondNum!).toString();
        history =
            firstNum.toString() + operation.toString() + secondNum.toString();
      }

      if (operation == "÷") {
        res = (firstNum! / secondNum!).toString();
        history =
            firstNum.toString() + operation.toString() + secondNum.toString();
      }

      // if (operation == "%") {
      //   res = ((firstNum! * secondNum!)/ 100).toString();
      //   history = firstNum.toString() + operation.toString() + secondNum.toString();
      // }
    } else {
      res = int.parse(output + btnValue).toString();
    }

    setState(() {
      output = res;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //backgroundColor: Color(0xFF283637),
      appBar: AppBar(
        leading: Icon(Icons.menu),
        title: Text("My Calculator"),
      ),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Container(
              alignment: Alignment(1, 1),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  history,
                  style: TextStyle(
                    //fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: Colors.grey,
                  ),
                ),
              ),
            ),
            Container(
              alignment: Alignment(1, 1),
              child: Text(
                output,
                style: TextStyle(
                  fontSize: 80,
                ),
              ),
            ),
            Row(
              children: [
                CalculatorButton(
                  btnText: "AC",
                  fillColor: 0xDD000000,
                  textColor: Colors.white,
                  flexValue: 2,
                  onBtnPressed: btnOnClick,
                ),
                CalculatorButton(
                  btnText: "%",
                  fillColor: 0xDD000000,
                  textColor: Colors.white,
                  flexValue: 1,
                  onBtnPressed: btnOnClick,
                ),
                CalculatorButton(
                  btnText: "÷",
                  fillColor: 0xFFFFC300,
                  textColor: Colors.white,
                  flexValue: 1,
                  onBtnPressed: btnOnClick,
                ),
              ],
            ),
            Row(
              children: [
                CalculatorButton(
                  btnText: "7",
                  fillColor: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                  onBtnPressed: btnOnClick,
                ),
                CalculatorButton(
                  btnText: "8",
                  fillColor: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                  onBtnPressed: btnOnClick,
                ),
                CalculatorButton(
                  btnText: "9",
                  fillColor: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                  onBtnPressed: btnOnClick,
                ),
                CalculatorButton(
                  btnText: "x",
                  fillColor: 0xFFFFC300,
                  textColor: Colors.white,
                  flexValue: 1,
                  onBtnPressed: btnOnClick,
                ),
              ],
            ),
            Row(
              children: [
                CalculatorButton(
                  btnText: "4",
                  fillColor: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                  onBtnPressed: btnOnClick,
                ),
                CalculatorButton(
                  btnText: "5",
                  fillColor: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                  onBtnPressed: btnOnClick,
                ),
                CalculatorButton(
                  btnText: "6",
                  fillColor: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                  onBtnPressed: btnOnClick,
                ),
                CalculatorButton(
                  btnText: "-",
                  fillColor: 0xFFFFC300,
                  textColor: Colors.white,
                  flexValue: 1,
                  onBtnPressed: btnOnClick,
                ),
              ],
            ),
            Row(
              children: [
                CalculatorButton(
                  btnText: "1",
                  fillColor: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                  onBtnPressed: btnOnClick,
                ),
                CalculatorButton(
                  btnText: "2",
                  fillColor: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                  onBtnPressed: btnOnClick,
                ),
                CalculatorButton(
                  btnText: "3",
                  fillColor: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 1,
                  onBtnPressed: btnOnClick,
                ),
                CalculatorButton(
                  btnText: "+",
                  fillColor: 0xFFFFC300,
                  textColor: Colors.white,
                  flexValue: 1,
                  onBtnPressed: btnOnClick,
                ),
              ],
            ),
            Row(
              children: [
                CalculatorButton(
                  btnText: "0",
                  fillColor: 0xFF6C807F,
                  textColor: Colors.white,
                  flexValue: 3,
                  onBtnPressed: btnOnClick,
                ),
                // CalculatorButton(
                //   btnText: ".",
                //   fillColor: 0xFF6C807F,
                //   textColor: Colors.white,
                //   flexValue: 1,
                // ),
                CalculatorButton(
                  btnText: "=",
                  fillColor: 0xFFFFC300,
                  textColor: Colors.white,
                  flexValue: 1,
                  onBtnPressed: btnOnClick,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class CalculatorButton extends StatelessWidget {
  final String btnText;
  final int fillColor;
  final Color textColor;
  final int flexValue;
  final Function onBtnPressed;

  const CalculatorButton(
      {Key? key,
      required this.btnText,
      required this.fillColor,
      required this.textColor,
      required this.flexValue,
      required this.onBtnPressed})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: flexValue,
      child: Container(
        height: 90,
        decoration: BoxDecoration(
          color: Color(fillColor),
          border: Border.fromBorderSide(
            BorderSide(width: 2),
          ),
        ),
        child: TextButton(
          onPressed: () => onBtnPressed(btnText),
          child: Text(
            "$btnText",
            style: TextStyle(fontSize: 30, color: textColor),
          ),
        ),
      ),
    );
  }
}
